<!DOCTYPE html>
<html>
<head>
  <title>Security Blog</title>
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body onload="showSlides();">
  <?php echo $_COOKIE['is_admin'];  ?>
<div class="page">
<div class="header">
<div class="header-top">
<h1> Security <span> Blog </span></h1>
</div>
<div class="topmenu">
<ul>
  < <li style="padding-left: 0px;"><a href="index.php"><span>Home</span></a></li>
  <li><a href="about.php"><span> About us</span></a></li>
  <li><a href="post.php"><span> Create Post</span></a></li>
  <li><a href="showpost.php"><span> View Posts</span></a></li>
  <li><a href="login.php"><span> Log in</span></a></li>
  <li><a href="register.php"><span> Register</span></a></li>
  <li><a href="logout.php"><span> log out</span></a></li>
</ul>
</div>
</div>


<div style="background-color:#FFFFFF;" class="content">
<h1 style="color:darkred; font-family:Times; font-style:bold; font-size:40px;"> Are Security And Customer Experience Mutually Exclusive For Banks?</h1>
<p style="color:black; font-family:Times; font-style:bold; font-size:20px;"> Customer experience and security aren’t mutually exclusive</p>
<p style="color:black; font-family:Times; font-size:16px;">Most customers are aware of the risks they are facing when it comes to online and mobile banking and are happy to put up with some extra steps to prevent any potential data breaches or fraud.  As a result, banks don’t have to choose between security and satisfied customers and instead they can look to create the perfect balance between protecting their customers’ interest while also providing a seamless digital experience.</p>

</script>
</div>
<div class="footer">
<ul>
  <li style="border-left: medium none;"><a href="index.php"><span>Home</span></a></li>
  <li><a href="about.php"><span>About us</span></a></li>
  <li><a href="article.php"><span>Article</span></a></li>
  <li><a href="contact.php"><span>Contact us</span></a></li>
</ul>
</div>
</div>

</body></html>