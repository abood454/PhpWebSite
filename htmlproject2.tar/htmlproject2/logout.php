<?php 

setcookie("name", "hahaha", time()-3600, "/","", 0);
setcookie("is_admin","hahahahaha", time()-3600, "/", "",  0);
       header("location: index.php");

 ?>