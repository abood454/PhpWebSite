<?php

     include("dbcon.php");


    
   if(!isset($_COOKIE['is_admin'])||$_COOKIE["is_admin"]===0)
{
   header("location: login.php");

}
  
if(isset($_POST['makeadmin'])){



      
      $sql = "UPDATE users SET is_admin='1' where email=".$_POST['makeadmin'];
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);

      $count = mysqli_num_rows($result);
      if($count==0){
      echo "<h1>user not found</h1> ";
      }
      else {echo "<h1>admin updated<h1>";}
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>Admin Page</title>
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body onload="showSlides();">
  <?php echo $_COOKIE['is_admin'];  ?>
<div class="page">
<div class="header">
<div class="header-top">
<h1> Security <span> Blog </span></h1>
</div>
<div class="topmenu">
<ul>
   <li style="padding-left: 0px;"><a href="index.php"><span>Home</span></a></li>
  <li><a href="about.php"><span> About us</span></a></li>
  <li><a href="post.php"><span> Create Post</span></a></li>
  <li><a href="showpost.php"><span> View Posts</span></a></li>
  <li><a href="login.php"><span> Log in</span></a></li>
  <li><a href="register.php"><span> Register</span></a></li>
  <li><a href="logout.php"><span> log out</span></a></li>
</ul>
</div>
</div>
<div style="background-color:#FFFFFF;" class="content">
<form action="admin.php" method="POST">
<label style="font-style:bold; color:gray; font-family:Times;font-family:Times;font-family:Times;font-family:Times;font-family:Times;">Search Users by E-mail</label><br> <input type="text" name="search" value="">
<input type="submit">
</form>
<br>
<br>
<br>
<form action="admin.php" method="POST">
<label style="font-style:bold; color:gray; font-family:Times">Add Admin</label><br> <input type="text" name="makeadmin" value="">
<input type="submit">
</form>
<?php  
if(isset($_POST['search'])){



      
      $sql = "SELECT name ,email ,is_admin FROM users WHERE email = '".$_POST['search']."'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);

      $count = mysqli_num_rows($result);
      if($count==0){
      echo "<h1>no users found</h1> ";
      }
      else
      	echo "<script>"."function view() {
      		var table = document.getElementById(\"res\");
			var row = table.insertRow(1);

			var cell1 = row.insertCell(0);
			var cell2= row.insertCell(1)
			var cell3 = row.insertCell(2);


cell1.innerHTML = \" " . $row['name']."\"
cell1.style.border=\"solid black 2px\";

cell2.innerHTML = \"" . $row['email']."\"
cell2.style.border=\"solid black 2px\";

cell3.innerHTML = \"" . $row['is_admin']."\"
cell3.style.border=\"solid black 2px\";

}

 "." view();
 </script>";

 echo '<script type="text/javascript">',
     'view();',
     '</script>';
}
?>


<div >

<table id="res">
	<tr>
		<th>name</th>
		<th>email</th>
		<th>admin</th>

	</tr>





</table>

	</div>

</div>
<div class="footer">
<ul>
  <li style="border-left: medium none;"><a href="index.php"><span>Home</span></a></li>
  <li><a href="about.php"><span>About us</span></a></li>
  <li><a href="article.php"><span>Article</span></a></li>
  <li><a href="contact.php"><span>Contact us</span></a></li>
</ul>
</div>
</div>

</body></html>