<!DOCTYPE html>
<html>
<head>
  <title>Post</title>
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body >
 
<div class="page">
<div class="header">
<div class="header-top">
<h1> Security <span> Blog </span></h1>
</div>
<div class="topmenu">
<ul>
   <li style="padding-left: 0px;"><a href="index.php"><span>Home</span></a></li>
  <li><a href="about.php"><span> About us</span></a></li>
  <li><a href="post.php"><span> Create Post</span></a></li>
  <li><a href="showpost.php"><span> View Posts</span></a></li>
  <li><a href="login.php"><span> Log in</span></a></li>
  <li><a href="register.php"><span> Register</span></a></li>
  <li><a href="logout.php"><span> log out</span></a></li>
</ul>
</div>
</div>


<div style="background-color:#FFFFFF;" class="content">
	<?php

if (isset($_GET['postid'])) {


include("dbcon.php");
 $name = "SELECT name,post FROM posts WHERE id ='".$_GET['postid']."';";

      $result = mysqli_query($db,$name);
      $data=mysqli_fetch_assoc($result);
       echo "<h1>".$data['name']."</h1>";
       echo "<p>".$data['post']."</p>";

}else{

	echo "<h1>Post not found<h1>";
}


	  ?>

</div>
<div class="footer">
<ul>
  <li style="border-left: medium none;"><a href="index.php"><span>Home</span></a></li>
  <li><a href="about.php"><span>About us</span></a></li>
  <li><a href="article.php"><span>Article</span></a></li>
  <li><a href="contact.php"><span>Contact us</span></a></li>
</div>
</div>

</body></html>