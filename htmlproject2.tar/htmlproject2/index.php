<!DOCTYPE html>
<html>
<head>
  <title>Security Blog</title>
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body onload="showSlides();">
<div class="page">
<div class="header">
<div class="header-top">
<h1> Security <span> Blog </span></h1>
</div>
<div class="topmenu">
<ul>
  <li style="padding-left: 0px;"><a href="index.php"><span>Home</span></a></li>
  <li><a href="about.php"><span> About us</span></a></li>
  <li><a href="post.php"><span> Create Post</span></a></li>
  <li><a href="showpost.php"><span> View Posts</span></a></li>
  <li><a href="login.php"><span> Log in</span></a></li>
  <li><a href="register.php"><span> Register</span></a></li>
  <li><a href="logout.php"><span> log out</span></a></li>
</ul>
</div>
</div>


<div class="content">
<div class="slideshow-container">
<?php
include("dbcon.php");
 $name = "SELECT name,post,id FROM posts ORDER BY id DESC limit 3 ";
      $result = mysqli_query($db,$name);
      
      while($row = mysqli_fetch_assoc($result)) {
        echo "<div class=\"mySlides\" fade> \n";
      echo "<h2><span><a href=\"viewpost.php?postid=".$row['id'] ."\" >".$row['name']." </a></span></h2>\n";
      echo "<p>".$row['post']."</p>\n </div>\n";     
       }

  ?>
<script>
var slideIndex = 0;


function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 6420);
}
</script>

<br>
<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
</div>
</div>
</script>
</div>
<div class="footer">
<ul>
  <li style="border-left: medium none;"><a href="index.php"><span>Home</span></a></li>
  <li><a href="about.php"><span>About us</span></a></li>
  <li><a href="article.php"><span>Article</span></a></li>
  <li><a href="contact.php"><span>Contact us</span></a></li>
</ul>
</div>
</div>

</body></html>