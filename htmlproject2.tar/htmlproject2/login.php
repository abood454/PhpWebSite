<?php

   session_start();
     include("dbcon.php");

      if(isset($_COOKIE['name']))
{
   header("location: index.php");

}
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $email = $_POST['email'];
      $password = $_POST['password']; 
      
      $sql = "SELECT id FROM users WHERE email = '".$email."' and password = '".$password."'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      
      $count = mysqli_num_rows($result);
      

      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {

      $sql = "SELECT is_admin FROM users WHERE email = '".$email."'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      
            
            setcookie("name", $_POST['email'], time()+3600, "/","", 0);
   			setcookie("is_admin", $row['is_admin'], time()+3600, "/", "",  0);

       header("location: index.php");
      }else {
         echo "Your Login Name or Password is invalid";
      }
   }
?>

<!DOCTYPE html>
<html>
<head>
  <link href="css/style.css" rel="stylesheet" type="text/css">
<title> styled.html </title></head>
<body>
<div id="a">
<form id="f" action="login.php" method="post">


<label>Email: </label><br>
<input id="w" type="mail" name="email"  required><br>

<label>password : </label><br>
<input id="e" type="password" name="password"  required><br>



<input id="t" type="submit" value="Submit">
</form>

</div>
</body>
</html>
