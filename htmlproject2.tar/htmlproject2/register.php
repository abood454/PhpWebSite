<?php

    include("dbcon.php");


//debug 

      if(isset($_COOKIE['name']))
{
   header("location: index.php");

}

if(isset($_POST['email'])&&isset($_POST['password'])&&isset($_POST['name'])){

$sql = "INSERT INTO users (name, email, password,is_admin)
    VALUES ('".$_POST["name"]."','".$_POST["email"]."','".  $_POST["password"] ."','" . 1 ."')";

echo $sql;
if ($db->query($sql) === TRUE) {
    echo "New user created successfully"."<a href=index.php>  go back to main</a>";
}
}
  ?>

<!DOCTYPE html>
<html>
<head>
  <link href="css/style.css" rel="stylesheet" type="text/css">
<title> styled. </title>
</head>
<body>
<div id="a">
<form id="f" action="register.php" method="POST">
<label>Full name: </label><br>
<input id="q" type="text" name="name"  required><br>

<label>Email: </label><br>
<input id="w" type="mail" name="email" required><br>

<label>password : </label><br>
<input id="e" type="password" name="password"  required><br>

<label>confirm password : </label><br>
<input id="r" type="password" name="confirm password"  required onchange="pass()"><br>
<label id="zz"></label>
<input id="t" type="submit" value="Submit">
</form>
<script type="text/javascript"> 
	function pass(){
var x =document.getElementById("e").value;
var y =document.getElementById("r").value;

if(x!=y){


document.getElementById("zz").innerHTML="passwords doesent match";
	document.getElementById("zz").style.color="red";

}else {

	document.getElementById("zz").innerHTML="";
}
}



</script>
</div>
</body>
</html>
