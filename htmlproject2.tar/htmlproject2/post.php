<?php

     include("dbcon.php");


    
   if(!isset($_COOKIE['is_admin'])||$_COOKIE["is_admin"]===0)
{
   header("location: login.php");

}
//debug 



if(isset($_POST['name'])&&isset($_POST['post'])){


//$sql = "INSERT INTO post (name,post,byuser) VALUES ( '$_POST['name']' , '$_POST['post']', ' $_SESSION['is_admin']' )";

      $name = "SELECT name FROM users WHERE email = '".$_COOKIE["name"]."'";
      $result = mysqli_query($db,$name);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      

$sql = "INSERT INTO posts (name, post, byuser)
    VALUES ('".mysqli_real_escape_string($db,$_POST["name"])."','".mysqli_real_escape_string($db,$_POST["post"])."','" .mysqli_real_escape_string($db,$row['name']) ."')";

//$sqlq = "INSERT INTO post (name,post,byuser) VALUES (' hi', 'hiiii ', '')";

if ($db->query($sql) === TRUE) {
    echo "New record created successfully";
}
}
  ?><!DOCTYPE html>
<html>
<head>
  <title>Post</title>
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body onload="showSlides();">
  <?php echo $_COOKIE['is_admin'];  ?>
<div class="page">
<div class="header">
<div class="header-top">
<h1> Security <span> Blog </span></h1>
</div>
<div class="topmenu">
<ul>
   <li style="padding-left: 0px;"><a href="index.php"><span>Home</span></a></li>
  <li><a href="about.php"><span> About us</span></a></li>
  <li><a href="post.php"><span> Create Post</span></a></li>
  <li><a href="showpost.php"><span> View Posts</span></a></li>
  <li><a href="login.php"><span> Log in</span></a></li>
  <li><a href="register.php"><span> Register</span></a></li>
  <li><a href="logout.php"><span> log out</span></a></li>
</ul>
</div>
</div>


<div style="background-color:#FFFFFF;" class="content">
<h1 style="font-style:bold; font-size:30px; color:black;">Publish Post </h1>
<br>
<form action="post.php" method="POST" >
<label style="font-style:bold; font-size:18px; font-family:Times">Title</label><br>
<input type="test" name="name">
<br>
<br>
<br>
<label style="font-style:bold; font-size:18px; font-family:Times">Post</label><br>
<textarea name="post"> </textarea>
<br>
<input type="submit" value="Create Post" id="haha">
</form>

<div class="footer">
<ul>
  <li style="border-left: medium none;"><a href="index.php"><span>Home</span></a></li>
  <li><a href="about.php"><span>About us</span></a></li>
  <li><a href="article.php"><span>Article</span></a></li>
  <li><a href="contact.php"><span>Contact us</span></a></li>
</ul>
</div>
</div>

</body></html>