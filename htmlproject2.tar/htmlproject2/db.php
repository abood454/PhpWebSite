 <?php

 //change those
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// sql to create table
$sql = "CREATE TABLE users (
id INT(4) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(30) NOT NULL,
email VARCHAR(50),
password VARCHAR(50),
is_admin INT(1) NOT NULL, 
reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "Table users created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}


$sql = "CREATE TABLE posts (
id INT(4) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(50) NOT NULL,
post TEXT NOT NULL,
posttime TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
byuser VARCHAR(50) NOT NULL

)";

if ($conn->query($sql) === TRUE) {
    echo "Table posts created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$sql = "INSERT INTO users (name, email, password,is_admin)
    VALUES ('admin','admin@admin.com','admin','1')"; //create admin acc

echo $sql;
if ($db->query($sql) === TRUE) {
    echo "New user created successfully"."<a href=index.php>  go back to main</a>";
}

$conn->close();
?> 