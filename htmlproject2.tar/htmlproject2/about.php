<!DOCTYPE html>
<html>
<head>
  <title>Security Blog</title>
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body onload="showSlides();">
  <?php echo $_COOKIE['is_admin'];  ?>
<div class="page">
<div class="header">
<div class="header-top">
<h1> Security <span> Blog </span></h1>
</div>
<div class="topmenu">
<ul>
  <li style="padding-left: 0px;"><a href="index.php"><span>Home</span></a></li>
  <li><a href="about.php"><span> About us</span></a></li>
  <li><a href="post.php"><span> Create Post</span></a></li>
  <li><a href="showpost.php"><span> View Posts</span></a></li>
  <li><a href="login.php"><span> Log in</span></a></li>
  <li><a href="register.php"><span> Register</span></a></li>
  <li><a href="logout.php"><span> log out</span></a></li>

</ul>
</div>
</div>


<div style="background-color:#FFFFFF;" class="content">
<p style="color:darkred; font-family:Times; font-style:italic; font-size:18px;">Welcome to our Security Blog, here you will learn about ethical hacking and security procedures to maintain your html page, you can create an account to be able to view and create posts on this blog, Enjoy!</p>

</script>
</div>
<div class="footer">
<ul>
  <li style="border-left: medium none;"><a href="index.php"><span>Home</span></a></li>
  <li><a href="about.php"><span>About us</span></a></li>
  <li><a href="article.php"><span>Article</span></a></li>
  <li><a href="contact.php"><span>Contact us</span></a></li>
</ul>
</div>
</div>

</body></html>